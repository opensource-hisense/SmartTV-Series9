/* jconfigint.h.  Generated from jconfigint.h.in by configure.  */
/* libjpeg-turbo build number */
#define BUILD "20170323"

/* How to obtain function inlining. */
#define INLINE inline __attribute__((always_inline))

/* Define to the full name of this package. */
#define PACKAGE_NAME "libjpeg-turbo"

/* Version number of package */
#define VERSION "1.5.0"

/* The size of `size_t', as computed by sizeof. */
#define SIZEOF_SIZE_T 4
