#define ENABLE_PI 1
#include "tst-mutex3.c"
