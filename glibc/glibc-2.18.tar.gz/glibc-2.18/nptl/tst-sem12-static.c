#include "tst-sem12.c"
