#define USE_PTHREADS 1
#include "../elf/tst-execstack.c"
