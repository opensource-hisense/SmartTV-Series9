#define SINGLE_THREAD
#define __setreuid pthread_setreuid_np
#include <setreuid.c>
