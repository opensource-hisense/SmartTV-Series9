#define TYPE PTHREAD_MUTEX_ADAPTIVE_NP
#include "tst-mutex7.c"
