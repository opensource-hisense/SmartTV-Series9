#define ENABLE_PI 1
#include "tst-robust8.c"
