#include "tst-initializers1.c"
