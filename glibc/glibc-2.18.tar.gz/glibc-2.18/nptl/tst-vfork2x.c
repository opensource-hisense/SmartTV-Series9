#include <posix/tst-vfork2.c>
