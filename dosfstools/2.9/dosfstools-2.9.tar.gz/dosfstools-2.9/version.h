#ifndef _version_h
#define _version_h

#define	VERSION			"2.9"
#define VERSION_DATE	"15 May 2003"

#endif  /* _version_h */

