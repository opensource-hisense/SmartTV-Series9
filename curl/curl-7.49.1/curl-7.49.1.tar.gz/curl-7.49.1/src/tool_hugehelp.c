/* built-in manual is disabled, blank function */
#include "tool_hugehelp.h"
void hugehelp(void) {}
