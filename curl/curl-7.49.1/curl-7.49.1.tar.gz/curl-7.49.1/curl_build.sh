#! /bin/sh

export LDFLAGS="-L${INSTALL_DIR}/zlib/zlib-${ZLIB_VER}-${OSS_BUILD_TAG}/usr/lib -L${INSTALL_DIR}/openssl/openssl-${OPENSSL_VER}-${OSS_BUILD_TAG}/usr/lib -L${INSTALL_DIR}/c-ares/c-ares-${CARES_VER}-${OSS_BUILD_TAG}/usr/lib"
export LIBS="-lcares -lssl -lcrypto -lz"
export CPPFLAGS="-DDNS_QUERY_OPTION -I${INSTALL_DIR}/zlib/zlib-${ZLIB_VER}-${OSS_BUILD_TAG}/usr/include -I${INSTALL_DIR}/openssl/openssl-${OPENSSL_VER}-${OSS_BUILD_TAG}/usr/include -I${INSTALL_DIR}/c-ares/c-ares-${CARES_VER}-${OSS_BUILD_TAG}/usr/include"
export export CFLAGS="${CFLAGS} -fPIC"

make clean
make distclean
rm -rf ${INSTALL_DIR}/libcurl/curl-${CURL_VER}-${CURL_TAR_TAG}
rm -rf curl-${CURL_VER}-${CURL_TAR_TAG}-install.tar.bz2

export CC=${CROSS_COMPILE}-gcc

./configure \
--host=${CROSS_COMPILE}  \
--enable-shared \
--build=`uname -m`-linux \
--enable-debug \
--enable-ares \
--enable-ipv6 \
--disable-dict \
--disable-telnet \
--enable-file \
--disable-tftp \
--disable-ldap \
--disable-ftp \
--disable-sspi \
--disable-dependency-tracking \
--enable-thread \
--without-libidn \
--with-pic  \
--disable-manual \
--disable-verbose \
--without-libssh2 \
--with-random=dev/urandom \
--prefix=${INSTALL_DIR}/libcurl/curl-${CURL_VER}-${CURL_TAR_TAG}/usr/


make
MAKE_RET=$?
if [ $MAKE_RET -ne 0 ]; then
    echo "LIBCURL Build Fail....($MAKE_RET)"
    exit $MAKE_RET
else
    echo "LIBCURL Build OK..."
fi
#make DESTDIR=${DEST_DIR} install
make install
if [ $MAKE_RET -ne 0 ]; then
    echo "LIBCURL Install Fail....($MAKE_RET)"
    exit $MAKE_RET
else
    echo "LIBCURL Install OK..."
fi

cp ./lib/timeval.h ${INSTALL_DIR}/libcurl/curl-${CURL_VER}-${CURL_TAR_TAG}/usr/include
cp ./lib/rawstr.h ${INSTALL_DIR}/libcurl/curl-${CURL_VER}-${CURL_TAR_TAG}/usr/include
cp ./lib/curl_setup.h ${INSTALL_DIR}/libcurl/curl-${CURL_VER}-${CURL_TAR_TAG}/usr/include
cp ./lib/curl_config.h ${INSTALL_DIR}/libcurl/curl-${CURL_VER}-${CURL_TAR_TAG}/usr/include
cp ./lib/curl_setup_once.h ${INSTALL_DIR}/libcurl/curl-${CURL_VER}-${CURL_TAR_TAG}/usr/include
cp ./lib/setup.h ${INSTALL_DIR}/libcurl/curl-${CURL_VER}-${CURL_TAR_TAG}/usr/include
cp ./lib/setup_once.h ${INSTALL_DIR}/libcurl/curl-${CURL_VER}-${CURL_TAR_TAG}/usr/include
cp ./lib/curl_config.h ${INSTALL_DIR}/libcurl/curl-${CURL_VER}-${CURL_TAR_TAG}/usr/include

CURRENT_PATH=$(pwd)
cd ${INSTALL_DIR}/libcurl/curl-${CURL_VER}-${CURL_TAR_TAG}

tar -jcvf curl-${CURL_VER}-${CURL_TAR_TAG}-install.tar.bz2 usr
mv curl-${CURL_VER}-${CURL_TAR_TAG}-install.tar.bz2 ../

cd $CURRENT_PATH

exit 0 
