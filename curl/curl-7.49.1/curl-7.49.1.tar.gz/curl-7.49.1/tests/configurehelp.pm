# This is a generated file.  Do not edit.

package configurehelp;

use strict;
use warnings;
use Exporter;

use vars qw(
    @ISA
    @EXPORT_OK
    $Cpreprocessor
    );

@ISA = qw(Exporter);

@EXPORT_OK = qw(
    $Cpreprocessor
    );

$Cpreprocessor = 'armv7a-mediatek482_001_neon-linux-gnueabi-gcc -E -DDEBUGBUILD -DCURLDEBUG -DDNS_QUERY_OPTION -isystem /proj/mtk94036/Jiang/OSS/source/../library//zlib/zlib-1.2.3-armv7a-482-neon_ca9/usr/include -isystem /proj/mtk94036/Jiang/OSS/source/../library//openssl/openssl-1.0.2g-armv7a-482-neon_ca9/usr/include -isystem /proj/mtk94036/Jiang/OSS/source/../library//c-ares/c-ares-1.10.0-armv7a-482-neon_ca9/usr/include';

1;
