primitive\_tests uses gtest framework

fifo\_tests does not run under gtest
