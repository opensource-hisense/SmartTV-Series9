#! /bin/sh

echo "enter libnl-3.2.29 build"

export PATH="/mtkoss/gnuarm/neon_4.8.2_2.6.35_cortex-a9-ubuntu/x86_64/bin:$PATH"
export CROSS_COMPILE=armv7a-mediatek482_001_neon-linux-gnueabi-

make clean
make distclean

CC=${CROSS_COMPILE}gcc ./configure \
--host=armv7a-mediatek482_001_neon-linux-gnueabi \
--target=armv7a-mediatek482_001_neon-linux-gnueabi \
--disable-cli \
--enable-shared \
--disable-static \
--prefix=$(pwd)/../usr 

make
make install
