char *version_string = "bison++ Version 1.21.9-1, adapted from GNU bison by coetmeur@icdc.fr\nMaintained by Magnus Ekdahl <magnus@debian.org>\n";
